import os
import sqlite3
from datetime import datetime, date
from functools import wraps

import cv2
import numpy as np
from flask import Flask, render_template, request, redirect, url_for, session, flash
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename

APP_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(APP_DIR, "faculty_attendance.db")
DATA_DIR = os.path.join(APP_DIR, "face_data")
MODEL_PATH = os.path.join(APP_DIR, "face_model.yml")
os.makedirs(DATA_DIR, exist_ok=True)

app = Flask(__name__)
app.secret_key = os.environ.get("FLASK_SECRET_KEY", "change-this-demo-secret-before-use")
app.config["MAX_CONTENT_LENGTH"] = 5 * 1024 * 1024

# OpenCV's built-in frontal-face detector
CASCADE_PATH = cv2.data.haarcascades + "haarcascade_frontalface_default.xml"
face_detector = cv2.CascadeClassifier(CASCADE_PATH)

def db():
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    return con

def init_db():
    with db() as con:
        con.execute("""
            CREATE TABLE IF NOT EXISTS admins (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                password_hash TEXT NOT NULL
            )
        """)
        con.execute("""
            CREATE TABLE IF NOT EXISTS faculty (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                faculty_code TEXT UNIQUE NOT NULL,
                name TEXT NOT NULL,
                department TEXT NOT NULL
            )
        """)
        con.execute("""
            CREATE TABLE IF NOT EXISTS attendance (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                faculty_id INTEGER NOT NULL,
                attendance_date TEXT NOT NULL,
                attendance_time TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT 'Present',
                UNIQUE(faculty_id, attendance_date),
                FOREIGN KEY(faculty_id) REFERENCES faculty(id)
            )
        """)
        existing = con.execute("SELECT id FROM admins WHERE username='admin'").fetchone()
        if existing is None:
            con.execute(
                "INSERT INTO admins(username, password_hash) VALUES (?, ?)",
                ("admin", generate_password_hash("admin123"))
            )

def admin_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if "admin_id" not in session:
            return redirect(url_for("admin_login"))
        return fn(*args, **kwargs)
    return wrapper

def read_image(file_storage):
    raw = file_storage.read()
    arr = np.frombuffer(raw, dtype=np.uint8)
    image = cv2.imdecode(arr, cv2.IMREAD_COLOR)
    return image

def largest_face_gray(image):
    if image is None:
        return None
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    faces = face_detector.detectMultiScale(
        gray, scaleFactor=1.2, minNeighbors=5, minSize=(100, 100)
    )
    if len(faces) == 0:
        return None
    x, y, w, h = max(faces, key=lambda box: box[2] * box[3])
    face = gray[y:y+h, x:x+w]
    return cv2.resize(face, (200, 200))

def train_model():
    if not hasattr(cv2, "face"):
        raise RuntimeError(
            "OpenCV face module is missing. Install opencv-contrib-python, "
            "not opencv-python."
        )
    images, labels = [], []
    with db() as con:
        faculty_rows = con.execute("SELECT id FROM faculty").fetchall()
    for row in faculty_rows:
        person_dir = os.path.join(DATA_DIR, str(row["id"]))
        if not os.path.isdir(person_dir):
            continue
        for filename in os.listdir(person_dir):
            if filename.lower().endswith((".jpg", ".jpeg", ".png")):
                path = os.path.join(person_dir, filename)
                image = cv2.imread(path, cv2.IMREAD_GRAYSCALE)
                if image is not None:
                    images.append(cv2.resize(image, (200, 200)))
                    labels.append(int(row["id"]))
    if not images:
        raise RuntimeError("No face samples found. Register faculty face photos first.")
    recognizer = cv2.face.LBPHFaceRecognizer_create()
    recognizer.train(images, np.array(labels, dtype=np.int32))
    recognizer.save(MODEL_PATH)
    return len(images)

@app.route("/")
def home():
    today = date.today().isoformat()
    with db() as con:
        total = con.execute("SELECT COUNT(*) FROM faculty").fetchone()[0]
        present = con.execute(
            "SELECT COUNT(*) FROM attendance WHERE attendance_date=?",
            (today,)
        ).fetchone()[0]
    return render_template("index.html", total=total, present=present, today=today)

@app.route("/admin/login", methods=["GET", "POST"])
def admin_login():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        with db() as con:
            admin = con.execute("SELECT * FROM admins WHERE username=?", (username,)).fetchone()
        if admin and check_password_hash(admin["password_hash"], password):
            session.clear()
            session["admin_id"] = admin["id"]
            session["admin_name"] = username
            return redirect(url_for("dashboard"))
        flash("Incorrect username or password.")
    return render_template("admin_login.html")

@app.route("/admin/logout")
def admin_logout():
    session.clear()
    return redirect(url_for("home"))

@app.route("/admin")
@admin_required
def dashboard():
    with db() as con:
        faculty = con.execute("SELECT * FROM faculty ORDER BY name").fetchall()
        records = con.execute("""
            SELECT f.name, f.faculty_code, f.department,
                   a.attendance_date, a.attendance_time, a.status
            FROM attendance a JOIN faculty f ON f.id=a.faculty_id
            ORDER BY a.attendance_date DESC, a.attendance_time DESC
            LIMIT 100
        """).fetchall()
    return render_template("dashboard.html", faculty=faculty, records=records)

@app.route("/admin/register", methods=["GET", "POST"])
@admin_required
def register_faculty():
    if request.method == "POST":
        code = request.form.get("faculty_code", "").strip()
        name = request.form.get("name", "").strip()
        department = request.form.get("department", "").strip()
        photos = request.files.getlist("photos")
        if not code or not name or not department or not photos or all(not p.filename for p in photos):
            flash("Enter all faculty details and upload at least 3 face photos.")
            return redirect(url_for("register_faculty"))
        try:
            with db() as con:
                cur = con.execute(
                    "INSERT INTO faculty(faculty_code, name, department) VALUES (?, ?, ?)",
                    (code, name, department)
                )
                faculty_id = cur.lastrowid
        except sqlite3.IntegrityError:
            flash("Faculty code already exists.")
            return redirect(url_for("register_faculty"))

        person_dir = os.path.join(DATA_DIR, str(faculty_id))
        os.makedirs(person_dir, exist_ok=True)
        saved = 0
        for index, photo in enumerate(photos):
            if not photo or not photo.filename:
                continue
            image = read_image(photo)
            face = largest_face_gray(image)
            if face is None:
                continue
            cv2.imwrite(os.path.join(person_dir, f"sample_{index}.jpg"), face)
            saved += 1

        if saved < 3:
            # Remove incomplete registration so it can be retried cleanly.
            with db() as con:
                con.execute("DELETE FROM faculty WHERE id=?", (faculty_id,))
            for name_in_dir in os.listdir(person_dir):
                os.remove(os.path.join(person_dir, name_in_dir))
            os.rmdir(person_dir)
            flash(f"Only {saved} usable face photo(s) detected. Please upload at least 3 clear photos.")
            return redirect(url_for("register_faculty"))

        try:
            count = train_model()
            flash(f"Faculty registered. Saved {saved} face samples. Model trained using {count} samples.")
        except Exception as exc:
            flash(f"Faculty saved, but model training failed: {exc}")
        return redirect(url_for("dashboard"))
    return render_template("register.html")

@app.route("/attendance", methods=["GET", "POST"])
def mark_attendance():
    if request.method == "POST":
        photo = request.files.get("photo")
        if not photo or not photo.filename:
            flash("Capture a face photo first.")
            return redirect(url_for("mark_attendance"))
        if not os.path.exists(MODEL_PATH):
            flash("No trained face model. Ask the administrator to register faculty first.")
            return redirect(url_for("mark_attendance"))
        image = read_image(photo)
        face = largest_face_gray(image)
        if face is None:
            flash("No clear face detected. Try again in good lighting.")
            return redirect(url_for("mark_attendance"))
        try:
            recognizer = cv2.face.LBPHFaceRecognizer_create()
            recognizer.read(MODEL_PATH)
            label, confidence = recognizer.predict(face)
        except Exception:
            flash("Could not load the face model. Ask admin to retrain it.")
            return redirect(url_for("mark_attendance"))

        # LBPH confidence is a distance: smaller values indicate a closer match.
        # This demo threshold must be tested and calibrated for the actual camera.
        if confidence > 65:
            flash(f"Face not recognized (match distance {confidence:.1f}). Try again or contact admin.")
            return redirect(url_for("mark_attendance"))

        with db() as con:
            faculty = con.execute("SELECT * FROM faculty WHERE id=?", (int(label),)).fetchone()
            if faculty is None:
                flash("Recognized face is not linked to a faculty record.")
                return redirect(url_for("mark_attendance"))
            today = date.today().isoformat()
            now = datetime.now().strftime("%H:%M:%S")
            existing = con.execute(
                "SELECT id FROM attendance WHERE faculty_id=? AND attendance_date=?",
                (faculty["id"], today)
            ).fetchone()
            if existing:
                flash(f"{faculty['name']} is already marked present today.")
            else:
                con.execute("""
                    INSERT INTO attendance(faculty_id, attendance_date, attendance_time, status)
                    VALUES (?, ?, ?, 'Present')
                """, (faculty["id"], today, now))
                flash(f"Attendance marked for {faculty['name']} at {now}.")
        return redirect(url_for("mark_attendance"))
    return render_template("attendance.html")

@app.route("/admin/retrain", methods=["POST"])
@admin_required
def retrain():
    try:
        count = train_model()
        flash(f"Face model retrained with {count} samples.")
    except Exception as exc:
        flash(str(exc))
    return redirect(url_for("dashboard"))

if __name__ == "__main__":
    init_db()
    app.run(debug=True)
