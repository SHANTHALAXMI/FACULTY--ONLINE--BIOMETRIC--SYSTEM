ONLINE FACULTY BIOMETRIC ATTENDANCE - DEMO

1. Extract this folder and open it in VS Code.
2. Open Terminal > New Terminal.
3. Run: python -m pip install -r requirements.txt
4. Run: python app.py
5. Open http://127.0.0.1:5000 in Chrome or Edge.
6. Admin demo login: admin / admin123
7. Admin > Register Faculty Face. Add faculty code, name, department and at least 3 clear photos of the same consenting person.
8. Faculty > Mark Attendance. Start camera, capture a photo, then submit.
9. Admin dashboard shows faculty and recent attendance.

IMPORTANT:
- This is an educational prototype, not production-grade biometric security.
- Obtain informed consent before collecting face images.
- Face samples are stored in face_data/ and the model in face_model.yml; protect these files.
- Change the demo admin password and Flask secret before real deployment.
- LBPH is a basic face matcher and can be fooled by photos. It does NOT provide liveness detection.
- Do not use for payroll, disciplinary action, or official attendance without security, privacy, accuracy, and legal review.
- If OpenCV installation fails, try: python -m pip install --upgrade pip
  then: python -m pip install -r requirements.txt
